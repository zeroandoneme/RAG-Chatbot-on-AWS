import json
import boto3
import os

# grab environment variables
endpoint_name = os.environ['ENDPOINT_NAME']
runtime = boto3.client('runtime.sagemaker')


def lambda_handler(event, context):
    print(event)

    # input_data = json.dumps(event['body']).encode('utf-8')
    input_data = event['body']

    print("Received event: " + input_data)
    print(type(input_data))

    response_content_type = 'application/json'

    # Invoke the SageMaker endpoint
    response = runtime.invoke_endpoint(
        EndpointName=endpoint_name,
        ContentType='application/json',
        Body=input_data
    )

    # Read the response
    body = response['Body'].read().decode('utf-8')
    print(body)
    response = {'statusCode': 200, 'body': body,
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}}

    return response

